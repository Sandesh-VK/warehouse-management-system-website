<?php
$conn = mysqli_connect('localhost','root','','clgproj');

if (!$conn){
	echo "Not connected";
	exit();
}

?>